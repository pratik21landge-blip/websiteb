# Minakshi Multispeciality Dental Clinic & Implant Centre

Website for **Minakshi Multispeciality Dental Clinic & Implant Centre** ("मीनाक्षी दातांचा दवाखाना").

## 📍 Clinic Locations
- **Clinic 2 (Main Centre - Saswad Rd)**: Shop No. 03, Near Purandar Medical, Near Angraj Dhaba, Next to Khadimachin Chowk, Saswad Road, Kondhwa, Pune - 411048
- **Clinic 1 (Katraj Branch)**: Swami Samarth Nagar, Gokul Nagar Chowk, Katraj-Kondhwa Road, Katraj, Pune - 411046
- **Phone**: +91 99752 02188
- **WhatsApp**: +91 99752 02188

## 🩺 Doctors
- **Dr. Nikhil N. Kadam** — B.D.S. (Reg. No: A-31896)
- **Dr. (Mrs) Minakshi Dhage - Kadam** — B.D.S., M.P.H. Nutrition (Reg. No: A-29609)

## 📋 Services
1. Computerized X-ray
2. Dental Implants
3. Complete Denture
4. Fix Partial Denture (FPD)
5. Root Canal Treatment (RCT)
6. Single Seating Treatment (RCT)
7. Composite Restoration
8. Scaling & Oral Prophylaxis
9. Orthodontic Treatment
10. All Type Of Extraction
11. Gum Problems

## 🚀 How to Run Locally
Run:
```bash
node server.js
```
Then visit `http://localhost:3000` in your web browser.

## 🌐 How to Deploy to Netlify
1. Go to [Netlify Drop](https://app.netlify.com/drop).
2. Drag and drop this folder or `minakshi-dental-clinic.zip`.
3. Your site is live!
